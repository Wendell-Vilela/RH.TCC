package dao;

import model.FuncionarioAbsenteismo;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FuncionarioAbsenteismoDAO {

    public List<FuncionarioAbsenteismo> listarAbsenteismoFuncionarios() {
        
        List<FuncionarioAbsenteismo> lista = new ArrayList<>();
        
        String sql = "SELECT f.id_func, dp.nm_completo, " +
                     "COUNT(ra.id_ausencia) as total_faltas " +
                     "FROM funcionario f " +
                     "JOIN dado_pessoal dp ON f.id_func = dp.id_func " +
                     "LEFT JOIN reg_ausencia ra ON f.id_func = ra.id_func AND ra.tp_ausencia = 'Falta' " +
                     "GROUP BY f.id_func, dp.nm_completo";

        try (Connection conn = util.conexao.abrir();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                
                FuncionarioAbsenteismo fa = new FuncionarioAbsenteismo();
                
                fa.setId(rs.getInt("id_func"));
                fa.setNome(rs.getString("nm_completo"));
                
                int faltas = rs.getInt("total_faltas");
                fa.setFaltas(faltas);
                
                double taxa = (faltas / 22.0) * 100.0;
                fa.setTaxaAbs(Math.round(taxa * 100.0) / 100.0);

                lista.add(fa);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar absenteísmo dos funcionários: " + e.getMessage());
        }

        return lista;
    }
}
