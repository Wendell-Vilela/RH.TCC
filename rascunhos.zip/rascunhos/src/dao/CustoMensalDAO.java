package dao;

import model.CustoMensal;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustoMensalDAO {

    public CustoMensal buscarCustoMensal(int mes, int ano) {
        
        CustoMensal custoMensal = new CustoMensal();
        List<CustoMensal.Item> listaItens = new ArrayList<>();
        
        BigDecimal totalSalario = BigDecimal.ZERO;
        BigDecimal totalEncargo = BigDecimal.ZERO;
        BigDecimal totalBeneficio = BigDecimal.ZERO;

        String sqlItens = "SELECT f.id_func, dp.nm_completo, f.vl_salario_atual, f.vl_imposto, f.vl_a_receber " +
                          "FROM funcionario f " +
                          "JOIN dado_pessoal dp ON f.id_func = dp.id_func " +
                          "WHERE f.st_func = 'Ativo'";

        try (Connection conn = util.conexao.abrir();
             PreparedStatement stmt = conn.prepareStatement(sqlItens);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Long id = rs.getLong("id_func");
                String nome = rs.getString("nm_completo");
                BigDecimal salario = rs.getBigDecimal("vl_salario_atual");
                if (salario == null) salario = BigDecimal.ZERO;
                
                BigDecimal encargos = rs.getBigDecimal("vl_imposto");
                if (encargos == null) encargos = BigDecimal.ZERO;
                
                BigDecimal beneficios = rs.getBigDecimal("vl_a_receber");
                if (beneficios == null) beneficios = BigDecimal.ZERO;

                totalSalario = totalSalario.add(salario);
                totalEncargo = totalEncargo.add(encargos);
                totalBeneficio = totalBeneficio.add(beneficios);

                CustoMensal.Item item = new CustoMensal.Item(id, nome, salario, encargos, beneficios);
                listaItens.add(item);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao buscar itens de custos mensais: " + e.getMessage());
        }

        custoMensal.setSalarioTotal(totalSalario);
        custoMensal.setEncargoTotal(totalEncargo);
        custoMensal.setBeneficioTotal(totalBeneficio);
        
        BigDecimal investimentoTotal = totalSalario.add(totalEncargo).add(totalBeneficio);
        custoMensal.setInvestimentoTotal(investimentoTotal);
        
        custoMensal.setItens(listaItens);

        return custoMensal;
    }
}
