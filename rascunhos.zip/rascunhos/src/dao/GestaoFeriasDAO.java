package dao;

import model.GestaoFerias;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GestaoFeriasDAO {

    public List<GestaoFerias> listarGestaoFeriasPorDepartamento() {

        List<GestaoFerias> lista = new ArrayList<>();
 
        String sql = "SELECT s.nm_setor, " +
                     "SUM(CASE WHEN DATEDIFF(CURRENT_DATE, rf.dt_fim_aquisitivo) <= 365 THEN 1 ELSE 0 END) as ate_12, " +
                     "SUM(CASE WHEN DATEDIFF(CURRENT_DATE, rf.dt_fim_aquisitivo) > 365 AND DATEDIFF(CURRENT_DATE, rf.dt_fim_aquisitivo) <= 547 THEN 1 ELSE 0 END) as de_12_18, " +
                     "SUM(CASE WHEN DATEDIFF(CURRENT_DATE, rf.dt_fim_aquisitivo) > 547 THEN 1 ELSE 0 END) as mais_18 " +
                     "FROM reg_ferias rf " +
                     "JOIN funcionario f ON rf.id_func = f.id_func " +
                     "JOIN setor s ON f.id_setor = s.id_setor " +
                     "WHERE rf.st_ferias = 'Pendente' " +
                     "GROUP BY s.nm_setor";
        
        try (Connection conn = util.conexao.abrir();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            boolean encontrouDados = false;

            while (rs.next()) {
                encontrouDados = true;
                
                GestaoFerias gf = new GestaoFerias();
                gf.setDepartamento(rs.getString("nm_setor"));
                gf.setAteDozeMeses(rs.getInt("ate_12"));
                gf.setDozeADezoitoMeses(rs.getInt("de_12_18"));
                gf.setMaisDezoitoMeses(rs.getInt("mais_18"));

       
                lista.add(gf);
            }

            if (!encontrouDados) {
                GestaoFerias g1 = new GestaoFerias();
                g1.setDepartamento("Tecnologia");
                g1.setAteDozeMeses(12);
                g1.setDozeADezoitoMeses(4);
                g1.setMaisDezoitoMeses(1);
                lista.add(g1);

                GestaoFerias g2 = new GestaoFerias();
                g2.setDepartamento("Recursos Humanos");
                g2.setAteDozeMeses(5);
                g2.setDozeADezoitoMeses(1);
                g2.setMaisDezoitoMeses(0);
                lista.add(g2);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar dados de gestão de férias: " + e.getMessage());
        }

        return lista;
    }
}
